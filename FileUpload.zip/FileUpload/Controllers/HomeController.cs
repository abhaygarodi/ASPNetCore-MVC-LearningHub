using FileUpload.Models;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace FileUpload.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> singlefileupload(IFormFile singlefile)
        {
            if (ModelState.IsValid)
            {
                if (singlefile != null && singlefile.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", singlefile.FileName);
                    using (var stream = System.IO.File.Create(filepath))
                    {
                        await singlefile.CopyToAsync(stream);
                    }
                    return Content("Upload successfully");
                }
            }
            return View("Index");
        }
    }
}

