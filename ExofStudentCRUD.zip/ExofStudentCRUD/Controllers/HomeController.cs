using ExofStudentCRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;

namespace ExofStudentCRUD.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // READ - list all students
        public IActionResult Index()
        {
            var list = new List<Student>();
            string cs = _configuration.GetConnectionString("DefaultConnection");

            using (var con = new SqlConnection(cs))
            {
                con.Open();
                using (var cmd = new SqlCommand("SELECT * FROM Students ORDER BY Id DESC", con))
                using (var dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        list.Add(new Student
                        {
                            Id = (int)dr["Id"],
                            Name = dr["Name"].ToString(),
                            Age = (int)dr["Age"],
                            Email = dr["Email"].ToString(),
                            EnrolledOn = (DateTime)dr["EnrolledOn"]
                        });
                    }
                }
            }

            return View(list);
        }

        // CREATE - GET
        public IActionResult Create()
        {
            return View();
        }

        // CREATE - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student student)
        {
            if (!ModelState.IsValid) return View(student);

            string cs = _configuration.GetConnectionString("DefaultConnection");
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                string sql = "INSERT INTO Students (Name, Age, Email, EnrolledOn) VALUES (@Name, @Age, @Email, @EnrolledOn)";
                using (var cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@Name", student.Name ?? string.Empty);
                    cmd.Parameters.AddWithValue("@Age", student.Age);
                    cmd.Parameters.AddWithValue("@Email", student.Email ?? string.Empty);
                    cmd.Parameters.AddWithValue("@EnrolledOn", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction(nameof(Index));
        }

        // EDIT - GET
        public IActionResult Edit(int id)
        {
            Student? student = null;
            string cs = _configuration.GetConnectionString("DefaultConnection");
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                using (var cmd = new SqlCommand("SELECT * FROM Students WHERE Id = @Id", con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    using (var dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            student = new Student
                            {
                                Id = (int)dr["Id"],
                                Name = dr["Name"].ToString(),
                                Age = (int)dr["Age"],
                                Email = dr["Email"].ToString(),
                                EnrolledOn = (DateTime)dr["EnrolledOn"]
                            };
                        }
                    }
                }
            }

            if (student == null) return NotFound();
            return View(student);
        }

        // EDIT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Student student)
        {
            if (!ModelState.IsValid) return View(student);

            string cs = _configuration.GetConnectionString("DefaultConnection");
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                string sql = "UPDATE Students SET Name=@Name, Age=@Age, Email=@Email WHERE Id=@Id";
                using (var cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@Name", student.Name ?? string.Empty);
                    cmd.Parameters.AddWithValue("@Age", student.Age);
                    cmd.Parameters.AddWithValue("@Email", student.Email ?? string.Empty);
                    cmd.Parameters.AddWithValue("@Id", student.Id);
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction(nameof(Index));
        }

        // DELETE - GET (confirm)
        public IActionResult Delete(int id)
        {
            Student? student = null;
            string cs = _configuration.GetConnectionString("DefaultConnection");
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                using (var cmd = new SqlCommand("SELECT * FROM Students WHERE Id = @Id", con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    using (var dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            student = new Student
                            {
                                Id = (int)dr["Id"],
                                Name = dr["Name"].ToString(),
                                Age = (int)dr["Age"],
                                Email = dr["Email"].ToString(),
                                EnrolledOn = (DateTime)dr["EnrolledOn"]
                            };
                        }
                    }
                }
            }

            if (student == null) return NotFound();
            return View(student);
        }

        // DELETE - POST
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            string cs = _configuration.GetConnectionString("DefaultConnection");
            using (var con = new SqlConnection(cs))
            {
                con.Open();
                using (var cmd = new SqlCommand("DELETE FROM Students WHERE Id=@Id", con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
