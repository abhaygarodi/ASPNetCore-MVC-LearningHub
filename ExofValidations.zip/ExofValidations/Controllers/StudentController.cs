﻿using ExofValidations.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExofValidations.Controllers
{
    public class StudentController : Controller
    {
        // GET: /Student/Index
        public IActionResult Index()
        {
            return View(new Student());
        }

        // POST: /Student/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(Student model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Name = model.Name;
                ViewBag.Email = model.Email;
            }
            return View(model);
        }
    }
}
