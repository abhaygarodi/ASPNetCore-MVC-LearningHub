using ExofValidations.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ExofValidations.Controllers
{
    public class HomeController : Controller
    {
        // GET: /Home/Index
        public IActionResult Index()
        {
            return View(new User());
        }

        // POST: /Home/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(User model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Name = model.Name;
                ViewBag.Email = model.Email;
            }

            // return same view with model (so errors appear if invalid)
            return View(model);
        }

        // Optional Error action if needed by template
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(); // you can create Views/Home/Error.cshtml if needed
        }
    }
}
