﻿using System.ComponentModel.DataAnnotations;

namespace ExofValidations.Models
{
    public class User
    {
        [Required(ErrorMessage = "Name is Required")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Email is Required")]
        [EmailAddress(ErrorMessage = "Email is not valid")]
        public string? Email { get; set; }
    }
}
