using ExofDependncyInjection.Models;
using Microsoft.AspNetCore.Mvc;

namespace ExofDependncyInjection.Controllers
{
    public class HomeController : Controller
    {
        private readonly IRepository repository;

        public HomeController(IRepository repo)
        {
            repository = repo;
        }

        // READ: list all products
        public IActionResult Index()
        {
            return View(repository.Products);
        }

        // CREATE: show form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // CREATE: handle form post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                repository.AddProduct(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // EDIT: show edit form
        [HttpGet]
        public IActionResult Edit(string name)
        {
            var product = repository[name];
            if (product == null)
                return NotFound();

            return View(product);
        }

        // EDIT: handle form post
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                repository.UpdateProduct(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // DELETE: confirm page
        [HttpGet]
        public IActionResult Delete(string name)
        {
            var product = repository[name];
            if (product == null)
                return NotFound();

            return View(product);
        }

        // DELETE: handle confirm
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string name)
        {
            repository.DeleteProduct(name);
            return RedirectToAction("Index");
        }
    }
}
