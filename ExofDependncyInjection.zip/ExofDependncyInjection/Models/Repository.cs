﻿using System.Collections.Generic;

namespace ExofDependncyInjection.Models
{
    public class Repository : IRepository
    {
        private readonly Dictionary<string, Product> products;

        public Repository()
        {
            products = new Dictionary<string, Product>();

            // Seed data
            new List<Product> {
                new Product { Name = "Women Shoes", Price = 99M },
                new Product { Name = "Skirts", Price = 29.99M },
                new Product { Name = "Pants", Price = 40.5M }
            }.ForEach(p => AddProduct(p));
        }

        public IEnumerable<Product> Products => products.Values;

        public Product? this[string name] =>
            products.ContainsKey(name) ? products[name] : null;

        public void AddProduct(Product product)
        {
            if (!products.ContainsKey(product.Name))
                products[product.Name] = product;
        }

        public void UpdateProduct(Product product)
        {
            if (products.ContainsKey(product.Name))
                products[product.Name] = product;
        }

        public void DeleteProduct(string name)
        {
            if (products.ContainsKey(name))
                products.Remove(name);
        }
    }
}
