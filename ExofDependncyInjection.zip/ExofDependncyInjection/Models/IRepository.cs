﻿namespace ExofDependncyInjection.Models
{
    public interface IRepository
    {
        IEnumerable<Product> Products { get; }
        Product? this[string name] { get; }

        void AddProduct(Product product);
        void UpdateProduct(Product product);
        void DeleteProduct(string name);
    }
}
